﻿namespace logic
{
    public interface IFlowOperation
    {
        //what should be here?? todo
    }
}
