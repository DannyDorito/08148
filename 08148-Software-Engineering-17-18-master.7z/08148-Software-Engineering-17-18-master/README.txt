Sample code supplied to students.
