﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace submissionConformance {
  internal class ExceptionConformance : Exception {

    internal ExceptionConformance(String message) : base(message) {
    }
  }
}
